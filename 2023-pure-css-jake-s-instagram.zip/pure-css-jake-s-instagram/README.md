# Pure CSS | Jake's Instagram

A Pen created on CodePen.io. Original URL: [https://codepen.io/kotAndy/pen/gOBgXvO](https://codepen.io/kotAndy/pen/gOBgXvO).

There is an animating carousel of Jake's "photos" that resembles the Instagram post, using only scss.